<?php
/* ********************************************************************************
 * The content of this file is subject to the List & Related List View Edits ("License").
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT&M SRL
 * Portions created by IT&M SRL. are Copyright(C) IT&M SRL.
 * All Rights Reserved.
 * ****************************************************************************** */
$languageStrings = array(
	'ITMListEdit' => 'Danh sách chỉnh sửa',
	'SINGLE_ITMListEdit' => 'Danh sách chỉnh sửa',
	'LBL_ITMLISTEDIT_JS' => 'Danh sách chỉnh sửa Js',
	'LBL_ITM_SRL_LIST_EDIT' => 'Danh sách chỉnh sửa',
	'SINGLE_LBL_ITM_SRL_LIST_EDIT' => 'Danh sách chỉnh sửa',
        'LBL_ITMListEdit_CONFIG' => 'Danh sách Chỉnh sửa Cấu hình'
);

?>
