<?php /*
This File was developed by Stefan Warnat <vtiger@stefanwarnat.de>

It belongs to the Colorizer and must not be distrubuted without the complete extension
*/
${"GLOBALS"}["evdbndk"]="jsLanguageStrings";
${"GLOBALS"}["ssrnftoua"]="languageStrings";
${${"GLOBALS"}["ssrnftoua"]}=array("Colorizer"=>"Colorizer",);
${${"GLOBALS"}["evdbndk"]}=array();
?>