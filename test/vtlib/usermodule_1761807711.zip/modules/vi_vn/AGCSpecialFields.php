<?php
 /* * *******************************************************************************
 * The content of this file is subject to the AGCSpecialFields license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is AG Consulting (Andreas Goebel)
 * Portions created by AG Consulting (Andreas Goebel) are Copyright(C) 
 * AG Consulting (Andreas Goebel).
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = array(    
    'AGCSpecialFields' => 'SpecialFields',
    'LBL_ADD_SPECIAL_FIELD' => 'Create special fields',
    'LBL_FIELD_TYPE' => 'Field type',
    'LBL_FIELD_LABEL' => 'Field label',
    'LBL_OK' => 'Save',
    'ImageField' => 'Image-Field',
    'WysiwygField' => 'WYSIWYG-Field',
    'CountryPicklistField' => 'Country List-Field',
    'LBL_ADD_FIELD' => 'Create special field',    
);

?>
