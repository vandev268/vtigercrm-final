<?php

$languageStrings = array(
	'CheckList' => 'Checklist'
);
