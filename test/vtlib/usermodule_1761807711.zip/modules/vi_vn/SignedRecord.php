<?php
/* ********************************************************************************
 * The content of this file is subject to the Signed Record ("License");
 * You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is VTExperts.com
 * Portions created by VTExperts.com. are Copyright(C) VTExperts.com.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = Array(
	'SignedRecord' => 'Signed Documents',
	'Signed Record' => 'Signed Documents',
	'Signed Records' => 'Signed Documents',
	'SINGLE_SignedRecord' => 'Signed Documents',
	
	'LBL_CUSTOM_INFORMATION' => 'Custom Information',
	'LBL_DETAIL_INFORMATION' => 'Detail Information',
	'LBL_DETAIL' => 'Detail',

);

?>
