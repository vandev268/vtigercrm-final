<?php
/*********************************************************************************
 * The content of this file is subject to the All Filter 4 You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * *******************************************************************************/

$languageStrings = array(
    "LBL_MODULE_NAME" => "All Filter",
    "LBL_WELCOME" => "You can edit your All Filter.",
    "LBL_CHOOSE_MODULE" => "Choose your module:",
    "LBL_CHOOSE_COLUMNS" => "Choose columns and order: ",
    "LBL_MAX_NUMBER_FILTER_COLUMNS" => " :",
    "LBL_CANCEL" => "Cancel",
    "LBL_SAVE" => "Save",
    "LBL_NEXT" => "Continue",
);

$jsLanguageStrings = array(
);


