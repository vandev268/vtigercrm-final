<?php

/* * *******************************************************************************
 * The content of this file is subject to the MultiWarehouses4You license.
 * ("License"); You may not use this file except in compliance with the License
 * The Initial Developer of the Original Code is IT-Solutions4You s.r.o.
 * Portions created by IT-Solutions4You s.r.o. are Copyright(C) IT-Solutions4You s.r.o.
 * All Rights Reserved.
 * ****************************************************************************** */

$languageStrings = array(
);

$jsLanguageStrings = array(
    "LBL_DEACTIVATE_QUESTION" => "Do you really want to deactivate your license key?",
    "LBL_UNINSTALL_CONFIRM" => "Are you sure to completely remove Warehouses 4 You from your vTiger and deactivate your Warehouses 4 You license?",
);
