<?php
/**
 * Created by JetBrains PhpStorm.
 * User: Stefan Warnat <support@stefanwarnat.de>
 * Date: 13.02.14 17:51
 * You must not use this file without permission.
 */
require('Settings/SwVtTools.php');

$languageStrings = array_merge($languageStrings, array(
    'SwVtTools' => 'VtigerCRM Tools'
));
$jsLanguageStrings = array_merge($jsLanguageStrings, array(

));

